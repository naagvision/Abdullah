from django.shortcuts import render
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from .models import Contact
# Create your views here.
def home_view(request):

    return render(request,'apphtml/home.html')
def index(request):

    return render(request, 'apphtml/home.html')

def products(request):
    return render(request, 'apphtml/products.html')

def about_us(request):

    return render(request, 'apphtml/aboutus.html')

def contact(request):
    if request.method == 'POST':
        name = request.POST['myname']
        email = request.POST['email']
        phone = request.POST['phone']
        content = request.POST['content']
        contacts = Contact(name=name, email=email, phone=phone, content=content)

        contacts.save()
    return render(request, 'apphtml/base.html')


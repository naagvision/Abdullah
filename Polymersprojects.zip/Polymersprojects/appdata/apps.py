from django.apps import AppConfig


class AppdataConfig(AppConfig):
    name = 'appdata'
